import os
unc = r"C:\my_disk\edupunk\analytics_application\____projects\web development\mkdocs\mkdocs_data_table_integration"
os.chdir(unc)
os.getcwd()

# load data
_df_edupunk()

html_middle = df_edupunk.to_html()
html_middle = html_middle.replace('<table border="1" class="dataframe">', '<table id="myTable" class="table table-striped">')
#print(html_middle)

_html_start ="""
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Ashu's Responsive table</title>

    <link href="assets/data_table/bootstrap.min.css" rel="stylesheet">
    <script src="assets/data_table/jquery.min.js"></script>
    <link rel="stylesheet" href="assets/data_table/jquery.dataTables.min.css">
    </style>
    <script type="text/javascript" src="assets/data_table/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="assets/data_table/bootstrap.min.js"></script>

    <script>
        $(document).ready(function () {
            $('#myTable').dataTable();
        });
    </script>
</head>

<body style="margin:20px auto">
    <div class="container">
"""
#print(_html_start)


_html_end ="""
    </div>
</body>
</html>
"""
#print(_html_end)

html_final = _html_start+'\n' + html_middle + _html_end

with open(unc+r'\docs\data_table_through_python.html', 'w') as f:
    f.write(html_final)

