# data table integration

## iframe

<iframe
  src="static_table.html"
  style="width:100%; height:700px;" frameborder="0" allowfullscreen
></iframe>

## through python

<iframe
  src="data_table_through_python.html"
  style="width:100%; height:700px;" frameborder="0" allowfullscreen
></iframe>

## map

<iframe
  src="meat.html"
  style="width:100%; height:700px;" frameborder="0" allowfullscreen
></iframe>
