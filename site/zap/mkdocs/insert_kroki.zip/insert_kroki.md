---
hide:
    # - navigation
    # - toc
    - footer
---


# Insert.kroki

## Kroki


[kroki](https://kroki.io/){target="_blank"} | 
[Github](https://github.com/AVATEAM-IT-SYSTEMHAUS/mkdocs-kroki-plugin){target="_blank"} | 
[Examples](https://kroki.io/examples.html){target="_blank"}





### Block diagram

!!! info "kroki-blockdiag"
    ```
    blockdiag {
      blockdiag -> generates -> "block-diagrams";
      blockdiag -> is -> "very easy!";
    
      blockdiag [color = "greenyellow"];
      "block-diagrams" [color = "pink"];
      "very easy!" [color = "orange"];
    }
    ```
    ```kroki-blockdiag
    blockdiag {
      blockdiag -> generates -> "block-diagrams";
      blockdiag -> is -> "very easy!";
    
      blockdiag [color = "greenyellow"];
      "block-diagrams" [color = "pink"];
      "very easy!" [color = "orange"];
    }
    ```



### Sequence diagram

!!! info "kroki-seqdiag"
    ```
    seqdiag {
      browser  -> webserver [label = "GET /index.html"];
      browser <-- webserver;
      browser  -> webserver [label = "POST /blog/comment"];
      webserver  -> database [label = "INSERT comment"];
      webserver <-- database;
      browser <-- webserver;
    }
    ```
    ```kroki-seqdiag
    seqdiag {
      browser  -> webserver [label = "GET /index.html"];
      browser <-- webserver;
      browser  -> webserver [label = "POST /blog/comment"];
      webserver  -> database [label = "INSERT comment"];
      webserver <-- database;
      browser <-- webserver;
    }
    ```


### Activity diagram

!!! info "kroki-actdiag"
    ```
    actdiag {
      write -> convert -> image
    
      lane user {
        label = "User"
        write [label = "Writing reST"];
        image [label = "Get diagram IMAGE"];
      }
      lane actdiag {
        convert [label = "Convert reST to Image"];
      }
    }
    ```
    ```kroki-actdiag
    actdiag {
      write -> convert -> image
    
      lane user {
        label = "User"
        write [label = "Writing reST"];
        image [label = "Get diagram IMAGE"];
      }
      lane actdiag {
        convert [label = "Convert reST to Image"];
      }
    }
    ```


### Network diagram

!!! info "kroki-nwdiag"
    ```
    nwdiag {
      network dmz {
        address = "210.x.x.x/24"
    
        web01 [address = "210.x.x.1"];
        web02 [address = "210.x.x.2"];
      }
      network internal {
        address = "172.x.x.x/24";
    
        web01 [address = "172.x.x.1"];
        web02 [address = "172.x.x.2"];
        db01;
        db02;
      }
    }
    ```
    ```kroki-nwdiag
    nwdiag {
      network dmz {
        address = "210.x.x.x/24"
    
        web01 [address = "210.x.x.1"];
        web02 [address = "210.x.x.2"];
      }
      network internal {
        address = "172.x.x.x/24";
    
        web01 [address = "172.x.x.1"];
        web02 [address = "172.x.x.2"];
        db01;
        db02;
      }
    }
    ```


### Packet diagram

!!! info "kroki-packetdiag"
    ```
    packetdiag {
      colwidth = 32;
      node_height = 72;
    
      0-15: Source Port;
      16-31: Destination Port;
      32-63: Sequence Number;
      64-95: Acknowledgment Number;
      96-99: Data Offset;
      100-105: Reserved;
      106: URG [rotate = 270];
      107: ACK [rotate = 270];
      108: PSH [rotate = 270];
      109: RST [rotate = 270];
      110: SYN [rotate = 270];
      111: FIN [rotate = 270];
      112-127: Window;
      128-143: Checksum;
      144-159: Urgent Pointer;
      160-191: (Options and Padding);
      192-223: data [colheight = 3];
    }
    ```
    ```kroki-packetdiag
    packetdiag {
      colwidth = 32;
      node_height = 72;
    
      0-15: Source Port;
      16-31: Destination Port;
      32-63: Sequence Number;
      64-95: Acknowledgment Number;
      96-99: Data Offset;
      100-105: Reserved;
      106: URG [rotate = 270];
      107: ACK [rotate = 270];
      108: PSH [rotate = 270];
      109: RST [rotate = 270];
      110: SYN [rotate = 270];
      111: FIN [rotate = 270];
      112-127: Window;
      128-143: Checksum;
      144-159: Urgent Pointer;
      160-191: (Options and Padding);
      192-223: data [colheight = 3];
    }
    ```



### Rack diagram

!!! info "kroki-rackdiag"
    ```
    rackdiag {
      16U;
      1: UPS [2U];
      3: DB Server;
      4: Web Server;
      5: Web Server;
      6: Web Server;
      7: Load Balancer;
      8: L3 Switch;
    }
    ```
    ```kroki-rackdiag
    rackdiag {
      16U;
      1: UPS [2U];
      3: DB Server;
      4: Web Server;
      5: Web Server;
      6: Web Server;
      7: Load Balancer;
      8: L3 Switch;
    }
    ```




### Word Cloud


!!! info "kroki-vega"
    ```
    {
      "$schema": "https://vega.github.io/schema/vega/v5.json",
      "width": 800,
      "height": 400,
      "padding": 0,
    
      "data": [
        {
          "name": "table",
          "values": [
            "Declarative visualization grammars can accelerate development, facilitate retargeting across platforms, and allow language-level optimizations. However, existing declarative visualization languages are primarily concerned with visual encoding, and rely on imperative event handlers for interactive behaviors. In response, we introduce a model of declarative interaction design for data visualizations. Adopting methods from reactive programming, we model low-level events as composable data streams from which we form higher-level semantic signals. Signals feed predicates and scale inversions, which allow us to generalize interactive selections at the level of item geometry (pixels) into interactive queries over the data domain. Production rules then use these queries to manipulate the visualization’s appearance. To facilitate reuse and sharing, these constructs can be encapsulated as named interactors: standalone, purely declarative specifications of interaction techniques. We assess our model’s feasibility and expressivity by instantiating it with extensions to the Vega visualization grammar. Through a diverse range of examples, we demonstrate coverage over an established taxonomy of visualization interaction techniques.",
            "We present Reactive Vega, a system architecture that provides the first robust and comprehensive treatment of declarative visual and interaction design for data visualization. Starting from a single declarative specification, Reactive Vega constructs a dataflow graph in which input data, scene graph elements, and interaction events are all treated as first-class streaming data sources. To support expressive interactive visualizations that may involve time-varying scalar, relational, or hierarchical data, Reactive Vega’s dataflow graph can dynamically re-write itself at runtime by extending or pruning branches in a data-driven fashion. We discuss both compile- and run-time optimizations applied within Reactive Vega, and share the results of benchmark studies that indicate superior interactive performance to both D3 and the original, non-reactive Vega system.",
            "We present Vega-Lite, a high-level grammar that enables rapid specification of interactive data visualizations. Vega-Lite combines a traditional grammar of graphics, providing visual encoding rules and a composition algebra for layered and multi-view displays, with a novel grammar of interaction. Users specify interactive semantics by composing selections. In Vega-Lite, a selection is an abstraction that defines input event processing, points of interest, and a predicate function for inclusion testing. Selections parameterize visual encodings by serving as input data, defining scale extents, or by driving conditional logic. The Vega-Lite compiler automatically synthesizes requisite data flow and event handling logic, which users can override for further customization. In contrast to existing reactive specifications, Vega-Lite selections decompose an interaction design into concise, enumerable semantic units. We evaluate Vega-Lite through a range of examples, demonstrating succinct specification of both customized interaction methods and common techniques such as panning, zooming, and linked selection."
          ],
          "transform": [
            {
              "type": "countpattern",
              "field": "data",
              "case": "upper",
              "pattern": "[\\w']{3,}",
              "stopwords": "(i|me|my|myself|we|us|our|ours|ourselves|you|your|yours|yourself|yourselves|he|him|his|himself|she|her|hers|herself|it|its|itself|they|them|their|theirs|themselves|what|which|who|whom|whose|this|that|these|those|am|is|are|was|were|be|been|being|have|has|had|having|do|does|did|doing|will|would|should|can|could|ought|i'm|you're|he's|she's|it's|we're|they're|i've|you've|we've|they've|i'd|you'd|he'd|she'd|we'd|they'd|i'll|you'll|he'll|she'll|we'll|they'll|isn't|aren't|wasn't|weren't|hasn't|haven't|hadn't|doesn't|don't|didn't|won't|wouldn't|shan't|shouldn't|can't|cannot|couldn't|mustn't|let's|that's|who's|what's|here's|there's|when's|where's|why's|how's|a|an|the|and|but|if|or|because|as|until|while|of|at|by|for|with|about|against|between|into|through|during|before|after|above|below|to|from|up|upon|down|in|out|on|off|over|under|again|further|then|once|here|there|when|where|why|how|all|any|both|each|few|more|most|other|some|such|no|nor|not|only|own|same|so|than|too|very|say|says|said|shall)"
            },
            {
              "type": "formula", "as": "angle",
              "expr": "[-45, 0, 45][~~(random() * 3)]"
            },
            {
              "type": "formula", "as": "weight",
              "expr": "if(datum.text=='VEGA', 600, 300)"
            }
          ]
        }
      ],
    
      "scales": [
        {
          "name": "color",
          "type": "ordinal",
          "domain": {"data": "table", "field": "text"},
          "range": ["#d5a928", "#652c90", "#939597"]
        }
      ],
    
      "marks": [
        {
          "type": "text",
          "from": {"data": "table"},
          "encode": {
            "enter": {
              "text": {"field": "text"},
              "align": {"value": "center"},
              "baseline": {"value": "alphabetic"},
              "fill": {"scale": "color", "field": "text"}
            },
            "update": {
              "fillOpacity": {"value": 1}
            },
            "hover": {
              "fillOpacity": {"value": 0.5}
            }
          },
          "transform": [
            {
              "type": "wordcloud",
              "size": [800, 400],
              "text": {"field": "text"},
              "rotate": {"field": "datum.angle"},
              "font": "Helvetica Neue, Arial",
              "fontSize": {"field": "datum.count"},
              "fontWeight": {"field": "datum.weight"},
              "fontSizeRange": [12, 56],
              "padding": 2
            }
          ]
        }
      ]
    }
    ```
    ```kroki-vega
    {
      "$schema": "https://vega.github.io/schema/vega/v5.json",
      "width": 800,
      "height": 400,
      "padding": 0,
    
      "data": [
        {
          "name": "table",
          "values": [
            "Declarative visualization grammars can accelerate development, facilitate retargeting across platforms, and allow language-level optimizations. However, existing declarative visualization languages are primarily concerned with visual encoding, and rely on imperative event handlers for interactive behaviors. In response, we introduce a model of declarative interaction design for data visualizations. Adopting methods from reactive programming, we model low-level events as composable data streams from which we form higher-level semantic signals. Signals feed predicates and scale inversions, which allow us to generalize interactive selections at the level of item geometry (pixels) into interactive queries over the data domain. Production rules then use these queries to manipulate the visualization’s appearance. To facilitate reuse and sharing, these constructs can be encapsulated as named interactors: standalone, purely declarative specifications of interaction techniques. We assess our model’s feasibility and expressivity by instantiating it with extensions to the Vega visualization grammar. Through a diverse range of examples, we demonstrate coverage over an established taxonomy of visualization interaction techniques.",
            "We present Reactive Vega, a system architecture that provides the first robust and comprehensive treatment of declarative visual and interaction design for data visualization. Starting from a single declarative specification, Reactive Vega constructs a dataflow graph in which input data, scene graph elements, and interaction events are all treated as first-class streaming data sources. To support expressive interactive visualizations that may involve time-varying scalar, relational, or hierarchical data, Reactive Vega’s dataflow graph can dynamically re-write itself at runtime by extending or pruning branches in a data-driven fashion. We discuss both compile- and run-time optimizations applied within Reactive Vega, and share the results of benchmark studies that indicate superior interactive performance to both D3 and the original, non-reactive Vega system.",
            "We present Vega-Lite, a high-level grammar that enables rapid specification of interactive data visualizations. Vega-Lite combines a traditional grammar of graphics, providing visual encoding rules and a composition algebra for layered and multi-view displays, with a novel grammar of interaction. Users specify interactive semantics by composing selections. In Vega-Lite, a selection is an abstraction that defines input event processing, points of interest, and a predicate function for inclusion testing. Selections parameterize visual encodings by serving as input data, defining scale extents, or by driving conditional logic. The Vega-Lite compiler automatically synthesizes requisite data flow and event handling logic, which users can override for further customization. In contrast to existing reactive specifications, Vega-Lite selections decompose an interaction design into concise, enumerable semantic units. We evaluate Vega-Lite through a range of examples, demonstrating succinct specification of both customized interaction methods and common techniques such as panning, zooming, and linked selection."
          ],
          "transform": [
            {
              "type": "countpattern",
              "field": "data",
              "case": "upper",
              "pattern": "[\\w']{3,}",
              "stopwords": "(i|me|my|myself|we|us|our|ours|ourselves|you|your|yours|yourself|yourselves|he|him|his|himself|she|her|hers|herself|it|its|itself|they|them|their|theirs|themselves|what|which|who|whom|whose|this|that|these|those|am|is|are|was|were|be|been|being|have|has|had|having|do|does|did|doing|will|would|should|can|could|ought|i'm|you're|he's|she's|it's|we're|they're|i've|you've|we've|they've|i'd|you'd|he'd|she'd|we'd|they'd|i'll|you'll|he'll|she'll|we'll|they'll|isn't|aren't|wasn't|weren't|hasn't|haven't|hadn't|doesn't|don't|didn't|won't|wouldn't|shan't|shouldn't|can't|cannot|couldn't|mustn't|let's|that's|who's|what's|here's|there's|when's|where's|why's|how's|a|an|the|and|but|if|or|because|as|until|while|of|at|by|for|with|about|against|between|into|through|during|before|after|above|below|to|from|up|upon|down|in|out|on|off|over|under|again|further|then|once|here|there|when|where|why|how|all|any|both|each|few|more|most|other|some|such|no|nor|not|only|own|same|so|than|too|very|say|says|said|shall)"
            },
            {
              "type": "formula", "as": "angle",
              "expr": "[-45, 0, 45][~~(random() * 3)]"
            },
            {
              "type": "formula", "as": "weight",
              "expr": "if(datum.text=='VEGA', 600, 300)"
            }
          ]
        }
      ],
    
      "scales": [
        {
          "name": "color",
          "type": "ordinal",
          "domain": {"data": "table", "field": "text"},
          "range": ["#d5a928", "#652c90", "#939597"]
        }
      ],
    
      "marks": [
        {
          "type": "text",
          "from": {"data": "table"},
          "encode": {
            "enter": {
              "text": {"field": "text"},
              "align": {"value": "center"},
              "baseline": {"value": "alphabetic"},
              "fill": {"scale": "color", "field": "text"}
            },
            "update": {
              "fillOpacity": {"value": 1}
            },
            "hover": {
              "fillOpacity": {"value": 0.5}
            }
          },
          "transform": [
            {
              "type": "wordcloud",
              "size": [800, 400],
              "text": {"field": "text"},
              "rotate": {"field": "datum.angle"},
              "font": "Helvetica Neue, Arial",
              "fontSize": {"field": "datum.count"},
              "fontWeight": {"field": "datum.weight"},
              "fontSizeRange": [12, 56],
              "padding": 2
            }
          ]
        }
      ]
    }
    ```




### UML diagram

!!! info "kroki-nomnoml"
    ```
    [<abstract>Marauder]<:--[Pirate]
    [Pirate]- 0..7[mischief]
    [jollyness]->[Pirate]
    [jollyness]->[rum]
    [jollyness]->[singing]
    [Pirate]-> *[rum|tastiness: Int|swig()]
    [Pirate]->[singing]
    [singing]<->[rum]
    
    [<start>st]->[<state>plunder]
    [plunder]->[<choice>more loot]
    [more loot]->[st]
    [more loot] no ->[<end>e]
    
    [<actor>Sailor] - [<usecase>shiver me;timbers]
    ```
    ```kroki-nomnoml
    [<abstract>Marauder]<:--[Pirate]
    [Pirate]- 0..7[mischief]
    [jollyness]->[Pirate]
    [jollyness]->[rum]
    [jollyness]->[singing]
    [Pirate]-> *[rum|tastiness: Int|swig()]
    [Pirate]->[singing]
    [singing]<->[rum]
    
    [<start>st]->[<state>plunder]
    [plunder]->[<choice>more loot]
    [more loot]->[st]
    [more loot] no ->[<end>e]
    
    [<actor>Sailor] - [<usecase>shiver me;timbers]
    ```


### Use case diagram

!!! info "kroki-plantuml"
    ```
    @startuml
    left to right direction
    skinparam packageStyle rectangle
    skinparam monochrome true
    actor customer
    actor clerk
    rectangle checkout {
      customer -- (checkout)
      (checkout) .> (payment) : include
      (help) .> (checkout) : extends
      (checkout) -- clerk
    }
    @enduml
    ```
    ```kroki-plantuml
    @startuml
    left to right direction
    skinparam packageStyle rectangle
    skinparam monochrome true
    actor customer
    actor clerk
    rectangle checkout {
      customer -- (checkout)
      (checkout) .> (payment) : include
      (help) .> (checkout) : extends
      (checkout) -- clerk
    }
    @enduml
    ```


### Work Breakdown Structure

!!! info "kroki-plantuml"
    ```
    @startwbs
    skinparam monochrome true
    * Business Process Modelling WBS
    ** Launch the project
    *** Complete Stakeholder Research
    *** Initial Implementation Plan
    ** Design phase
    *** Model of AsIs Processes Completed
    **** Model of AsIs Processes Completed1
    **** Model of AsIs Processes Completed2
    *** Measure AsIs performance metrics
    *** Identify Quick Wins
    ** Complete innovate phase
    @endwbs
    ```
    ```kroki-plantuml
    @startwbs
    skinparam monochrome true
    * Business Process Modelling WBS
    ** Launch the project
    *** Complete Stakeholder Research
    *** Initial Implementation Plan
    ** Design phase
    *** Model of AsIs Processes Completed
    **** Model of AsIs Processes Completed1
    **** Model of AsIs Processes Completed2
    *** Measure AsIs performance metrics
    *** Identify Quick Wins
    ** Complete innovate phase
    @endwbs
    ```


### Gantt

!!! info "kroki-mermaid"
    ```
    gantt
        title A Gantt Diagram
        dateFormat  YYYY-MM-DD
        section Section
        A task           :a1, 2014-01-01, 30d
        Another task     :after a1, 20d
        section Another
        Task in sec      :2014-01-12, 12d
        another task     :24d
    ```
    ```kroki-mermaid
    gantt
        title A Gantt Diagram
        dateFormat  YYYY-MM-DD
        section Section
        A task           :a1, 2014-01-01, 30d
        Another task     :after a1, 20d
        section Another
        Task in sec      :2014-01-12, 12d
        another task     :24d
    ```



### Syntax diagram

!!! info "kroki-pikchr"
    ```
    $r = 0.2in
    linerad = 0.75*$r
    linewid = 0.25
    
    # Start and end blocks
    #
    box "element" bold fit
    line down 50% from last box.sw
    dot rad 250% color black
    X0: last.e + (0.3,0)
    arrow from last dot to X0
    move right 3.9in
    box wid 5% ht 25% fill black
    X9: last.w - (0.3,0)
    arrow from X9 to last box.w
    
    
    # The main rule that goes straight through from start to finish
    #
    box "object-definition" italic fit at 11/16 way between X0 and X9
    arrow to X9
    arrow from X0 to last box.w
    
    # The LABEL: rule
    #
    arrow right $r from X0 then down 1.25*$r then right $r
    oval " LABEL " fit
    arrow 50%
    oval "\":\"" fit
    arrow 200%
    box "position" italic fit
    arrow
    line right until even with X9 - ($r,0) \
      then up until even with X9 then to X9
    arrow from last oval.e right $r*0.5 then up $r*0.8 right $r*0.8
    line up $r*0.45 right $r*0.45 then right
    
    # The VARIABLE = rule
    #
    arrow right $r from X0 then down 2.5*$r then right $r
    oval " VARIABLE " fit
    arrow 70%
    box "assignment-operator" italic fit
    arrow 70%
    box "expr" italic fit
    line right until even with X9 - ($r,0) \
      then up until even with X9 then to X9
    
    # The PRINT rule
    #
    arrow right $r from X0 then down 3.75*$r then right $r
    oval "\"print\"" fit
    arrow
    box "print-args" italic fit
    line right until even with X9 - ($r,0) \
      then up until even with X9 then to X9
    ```
    ```kroki-pikchr
    $r = 0.2in
    linerad = 0.75*$r
    linewid = 0.25
    
    # Start and end blocks
    #
    box "element" bold fit
    line down 50% from last box.sw
    dot rad 250% color black
    X0: last.e + (0.3,0)
    arrow from last dot to X0
    move right 3.9in
    box wid 5% ht 25% fill black
    X9: last.w - (0.3,0)
    arrow from X9 to last box.w
    
    
    # The main rule that goes straight through from start to finish
    #
    box "object-definition" italic fit at 11/16 way between X0 and X9
    arrow to X9
    arrow from X0 to last box.w
    
    # The LABEL: rule
    #
    arrow right $r from X0 then down 1.25*$r then right $r
    oval " LABEL " fit
    arrow 50%
    oval "\":\"" fit
    arrow 200%
    box "position" italic fit
    arrow
    line right until even with X9 - ($r,0) \
      then up until even with X9 then to X9
    arrow from last oval.e right $r*0.5 then up $r*0.8 right $r*0.8
    line up $r*0.45 right $r*0.45 then right
    
    # The VARIABLE = rule
    #
    arrow right $r from X0 then down 2.5*$r then right $r
    oval " VARIABLE " fit
    arrow 70%
    box "assignment-operator" italic fit
    arrow 70%
    box "expr" italic fit
    line right until even with X9 - ($r,0) \
      then up until even with X9 then to X9
    
    # The PRINT rule
    #
    arrow right $r from X0 then down 3.75*$r then right $r
    oval "\"print\"" fit
    arrow
    box "print-args" italic fit
    line right until even with X9 - ($r,0) \
      then up until even with X9 then to X9
    ```



### Mind Map

[Mind Map](https://plantuml.com/mindmap-diagram){target="_blank"}

#### E.g. 1

!!! info "kroki-plantuml"
    ```
    @startmindmap
    * Debian
    ** Ubuntu
    *** Linux Mint
    *** Kubuntu
    *** Lubuntu
    *** KDE Neon
    ** LMDE
    ** SolydXK
    ** SteamOS
    ** Raspbian with a very long name
    *** <s>Raspmbc</s> => OSMC
    *** <s>Raspyfi</s> => Volumio
    @endmindmap
    ```
    ```kroki-plantuml
    @startmindmap
    * Debian
    ** Ubuntu
    *** Linux Mint
    *** Kubuntu
    *** Lubuntu
    *** KDE Neon
    ** LMDE
    ** SolydXK
    ** SteamOS
    ** Raspbian with a very long name
    *** <s>Raspmbc</s> => OSMC
    *** <s>Raspyfi</s> => Volumio
    @endmindmap
    ```


#### E.g. 2

!!! info "kroki-plantuml"
    ```
    @startmindmap
    * root node
    	* some first level node
    		* second level node
    		* another second level node
    	* another first level node
    @endmindmap

    ```
    ```kroki-plantuml
    @startmindmap
    * root node
    	* some first level node
    		* second level node
    		* another second level node
    	* another first level node
    @endmindmap

    ```




#### E.g. 3

!!! info "kroki-plantuml"
    ```
    @startmindmap
    *_ root node
    **_ some first level node
    ***_ second level node
    ***_ another second level node
    ***_ foo
    ***_ bar
    ***_ foobar
    **_ another first level node
    @endmindmap
    ```
    ```kroki-plantuml
    @startmindmap
    *_ root node
    **_ some first level node
    ***_ second level node
    ***_ another second level node
    ***_ foo
    ***_ bar
    ***_ foobar
    **_ another first level node
    @endmindmap
    ```



#### E.g. 4

!!! info "kroki-plantuml"
    ```
    @startmindmap
    * Class Templates
    **:Example 1
    <code>
    template <typename T>
    class cname{
    void f1()<U+003B>
    ...
    }
    </code>
    ;
    **:Example 2
    <code>
    other template <typename T>
    class cname{
    ...
    </code>
    ;
    @endmindmap
    ```
    ```kroki-plantuml
    @startmindmap
    * Class Templates
    **:Example 1
    <code>
    template <typename T>
    class cname{
    void f1()<U+003B>
    ...
    }
    </code>
    ;
    **:Example 2
    <code>
    other template <typename T>
    class cname{
    ...
    </code>
    ;
    @endmindmap
    ```


#### E.g. 5

!!! info "kroki-plantuml"
    ```
    @startmindmap
    *[#Orange] Colors
    **[#lightgreen] Green
    **[#FFBBCC] Rose
    **[#lightblue] Blue
    @endmindmap
    ```
    ```kroki-plantuml
    @startmindmap
    *[#Orange] Colors
    **[#lightgreen] Green
    **[#FFBBCC] Rose
    **[#lightblue] Blue
    @endmindmap
    ```



#### E.g. 6

!!! info "kroki-plantuml"
    ```
    @startmindmap
    *[#Orange] root node
     *[#lightgreen] some first level node
      *[#FFBBCC] second level node
      *[#lightblue] another second level node
     *[#lightgreen] another first level node
    @endmindmap
    ```
    ```kroki-plantuml
    @startmindmap
    *[#Orange] root node
     *[#lightgreen] some first level node
      *[#FFBBCC] second level node
      *[#lightblue] another second level node
     *[#lightgreen] another first level node
    @endmindmap
    ```




#### E.g. 6

!!! info "kroki-plantuml"
    ```
    @startmindmap
    * count
    ** 100
    *** 101
    *** 102
    ** 200
    
    left side
    
    ** A
    *** AA
    *** AB
    ** B
    @endmindmap
    ```
    ```kroki-plantuml
    @startmindmap
    * count
    ** 100
    *** 101
    *** 102
    ** 200
    
    left side
    
    ** A
    *** AA
    *** AB
    ** B
    @endmindmap
    ```



































### BPMN

[BPMN](https://kroki.io/examples.html#bpmn){target="_none"}


### Bytefield

[Bytefield](https://kroki.io/examples.html#bytefield){target="_none"}


### Digital Timing diagram

!!! info "kroki-wavedrom"
    ```
    { signal: [
      { name: "clk",         wave: "p.....|..." },
      { name: "Data",        wave: "x.345x|=.x", data: ["head", "body", "tail", "data"] },
      { name: "Request",     wave: "0.1..0|1.0" },
      {},
      { name: "Acknowledge", wave: "1.....|01." }
    ]}
    ```
    ```kroki-wavedrom
    { signal: [
      { name: "clk",         wave: "p.....|..." },
      { name: "Data",        wave: "x.345x|=.x", data: ["head", "body", "tail", "data"] },
      { name: "Request",     wave: "0.1..0|1.0" },
      {},
      { name: "Acknowledge", wave: "1.....|01." }
    ]}
    ```

### Connected Servers

!!! info "kroki-svgbob"
    ```
                      .-,(  ),-.
       ___  _      .-(          )-.
      [___]|=| -->(                )      __________
      /::/ |_|     '-(          ).-' --->[_...__...°]
                      '-.( ).-'
                              \      ____   __
                               '--->|    | |==|
                                    |____| |  |
                                    /::::/ |__|
    ```
    ```kroki-svgbob
                      .-,(  ),-.
       ___  _      .-(          )-.
      [___]|=| -->(                )      __________
      /::/ |_|     '-(          ).-' --->[_...__...°]
                      '-.( ).-'
                              \      ____   __
                               '--->|    | |==|
                                    |____| |  |
                                    /::::/ |__|
    ```


### Ascii Art

[SVG Editor](https://ivanceras.github.io/svgbob-editor/){target="_none"}


!!! info "kroki-svgbob"
    ```
      _____
     /  O__]
    /  ___]
    \   \
     |   |
     |   |
     /   /
     \   \
     /   /
    ```
    ```kroki-svgbob
      _____
     /  O__]
    /  ___]
    \   \
     |   |
     |   |
     /   /
     \   \
     /   /
    ```



### Impossible trident

!!! info "kroki-pikchr"
    ```
    # Impossible trident pikchr script
    # https://en.wikipedia.org/wiki/Impossible_trident
    # pikchr script by Kees Nuyt, license Creative Commons BY-NC-SA
    # https://creativecommons.org/licenses/by-nc-sa/4.0/
    
    scale = 1.0
    eh = 0.5cm
    ew = 0.2cm
    ed = 2 * eh
    er = 0.4cm
    lws = 4.0cm
    lwm = lws + er
    lwl = lwm + er
    
    ellipse height eh width ew
    L1: line width lwl from last ellipse.n
    line width lwm from last ellipse.s
    LV: line height eh down
    
    move right er down ed from last ellipse.n
    ellipse height eh width ew
    L3: line width lws right from last ellipse.n to LV.end then down eh right ew
    line width lwm right from last ellipse.s then to LV.start
    
    move right er down ed from last ellipse.n
    ellipse height eh width ew
    line width lwl right from last ellipse.n then to L1.end
    line width lwl right from last ellipse.s then up eh
    ```
    ```kroki-pikchr
    # Impossible trident pikchr script
    # https://en.wikipedia.org/wiki/Impossible_trident
    # pikchr script by Kees Nuyt, license Creative Commons BY-NC-SA
    # https://creativecommons.org/licenses/by-nc-sa/4.0/
    
    scale = 1.0
    eh = 0.5cm
    ew = 0.2cm
    ed = 2 * eh
    er = 0.4cm
    lws = 4.0cm
    lwm = lws + er
    lwl = lwm + er
    
    ellipse height eh width ew
    L1: line width lwl from last ellipse.n
    line width lwm from last ellipse.s
    LV: line height eh down
    
    move right er down ed from last ellipse.n
    ellipse height eh width ew
    L3: line width lws right from last ellipse.n to LV.end then down eh right ew
    line width lwm right from last ellipse.s then to LV.start
    
    move right er down ed from last ellipse.n
    ellipse height eh width ew
    line width lwl right from last ellipse.n then to L1.end
    line width lwl right from last ellipse.s then up eh
    ```



### Context diagram

!!! info "kroki-c4plantuml"
    ```
    @startuml
    !include C4_Context.puml
    
    LAYOUT_WITH_LEGEND()
    
    title System Context diagram for Internet Banking System
    
    Person(customer, "Personal Banking Customer", "A customer of the bank, with personal bank accounts.")
    System(banking_system, "Internet Banking System", "Allows customers to view information about their bank accounts, and make payments.")
    
    System_Ext(mail_system, "E-mail system", "The internal Microsoft Exchange e-mail system.")
    System_Ext(mainframe, "Mainframe Banking System", "Stores all of the core banking information about customers, accounts, transactions, etc.")
    
    Rel(customer, banking_system, "Uses")
    Rel_Back(customer, mail_system, "Sends e-mails to")
    Rel_Neighbor(banking_system, mail_system, "Sends e-mails", "SMTP")
    Rel(banking_system, mainframe, "Uses")
    @enduml
    ```
    ```kroki-c4plantuml
    @startuml
    !include C4_Context.puml
    
    LAYOUT_WITH_LEGEND()
    
    title System Context diagram for Internet Banking System
    
    Person(customer, "Personal Banking Customer", "A customer of the bank, with personal bank accounts.")
    System(banking_system, "Internet Banking System", "Allows customers to view information about their bank accounts, and make payments.")
    
    System_Ext(mail_system, "E-mail system", "The internal Microsoft Exchange e-mail system.")
    System_Ext(mainframe, "Mainframe Banking System", "Stores all of the core banking information about customers, accounts, transactions, etc.")
    
    Rel(customer, banking_system, "Uses")
    Rel_Back(customer, mail_system, "Sends e-mails to")
    Rel_Neighbor(banking_system, mail_system, "Sends e-mails", "SMTP")
    Rel(banking_system, mainframe, "Uses")
    @enduml
    ```






### Container diagram

!!! info "kroki-c4plantuml"
    ```
    @startuml
    !include C4_Container.puml
    
    LAYOUT_TOP_DOWN()
    LAYOUT_WITH_LEGEND()
    
    title Container diagram for Internet Banking System
    
    Person(customer, Customer, "A customer of the bank, with personal bank accounts")
    
    System_Boundary(c1, "Internet Banking") {
        Container(web_app, "Web Application", "Java, Spring MVC", "Delivers the static content and the Internet banking SPA")
        Container(spa, "Single-Page App", "JavaScript, Angular", "Provides all the Internet banking functionality to cutomers via their web browser")
        Container(mobile_app, "Mobile App", "C#, Xamarin", "Provides a limited subset of the Internet banking functionality to customers via their mobile device")
        ContainerDb(database, "Database", "SQL Database", "Stores user registraion information, hased auth credentials, access logs, etc.")
        Container(backend_api, "API Application", "Java, Docker Container", "Provides Internet banking functionality via API")
    }
    
    System_Ext(email_system, "E-Mail System", "The internal Microsoft Exchange system")
    System_Ext(banking_system, "Mainframe Banking System", "Stores all of the core banking information about customers, accounts, transactions, etc.")
    
    Rel(customer, web_app, "Uses", "HTTPS")
    Rel(customer, spa, "Uses", "HTTPS")
    Rel(customer, mobile_app, "Uses")
    
    Rel_Neighbor(web_app, spa, "Delivers")
    Rel(spa, backend_api, "Uses", "async, JSON/HTTPS")
    Rel(mobile_app, backend_api, "Uses", "async, JSON/HTTPS")
    Rel_Back_Neighbor(database, backend_api, "Reads from and writes to", "sync, JDBC")
    
    Rel_Back(customer, email_system, "Sends e-mails to")
    Rel_Back(email_system, backend_api, "Sends e-mails using", "sync, SMTP")
    Rel_Neighbor(backend_api, banking_system, "Uses", "sync/async, XML/HTTPS")
    @enduml
    ```
    ```kroki-c4plantuml
    @startuml
    !include C4_Container.puml
    
    LAYOUT_TOP_DOWN()
    LAYOUT_WITH_LEGEND()
    
    title Container diagram for Internet Banking System
    
    Person(customer, Customer, "A customer of the bank, with personal bank accounts")
    
    System_Boundary(c1, "Internet Banking") {
        Container(web_app, "Web Application", "Java, Spring MVC", "Delivers the static content and the Internet banking SPA")
        Container(spa, "Single-Page App", "JavaScript, Angular", "Provides all the Internet banking functionality to cutomers via their web browser")
        Container(mobile_app, "Mobile App", "C#, Xamarin", "Provides a limited subset of the Internet banking functionality to customers via their mobile device")
        ContainerDb(database, "Database", "SQL Database", "Stores user registraion information, hased auth credentials, access logs, etc.")
        Container(backend_api, "API Application", "Java, Docker Container", "Provides Internet banking functionality via API")
    }
    
    System_Ext(email_system, "E-Mail System", "The internal Microsoft Exchange system")
    System_Ext(banking_system, "Mainframe Banking System", "Stores all of the core banking information about customers, accounts, transactions, etc.")
    
    Rel(customer, web_app, "Uses", "HTTPS")
    Rel(customer, spa, "Uses", "HTTPS")
    Rel(customer, mobile_app, "Uses")
    
    Rel_Neighbor(web_app, spa, "Delivers")
    Rel(spa, backend_api, "Uses", "async, JSON/HTTPS")
    Rel(mobile_app, backend_api, "Uses", "async, JSON/HTTPS")
    Rel_Back_Neighbor(database, backend_api, "Reads from and writes to", "sync, JDBC")
    
    Rel_Back(customer, email_system, "Sends e-mails to")
    Rel_Back(email_system, backend_api, "Sends e-mails using", "sync, SMTP")
    Rel_Neighbor(backend_api, banking_system, "Uses", "sync/async, XML/HTTPS")
    @enduml
    ```














### Container diagram Structurizr

[Structurizr](https://kroki.io/examples.html#structurizr-container){target="_none"}









### Component diagram

!!! info "kroki-c4plantuml"
    ```
    @startuml
    !include C4_Component.puml
    
    LAYOUT_WITH_LEGEND()
    
    title Component diagram for Internet Banking System - API Application
    
    Container(spa, "Single Page Application", "javascript and angular", "Provides all the internet banking functionality to customers via their web browser.")
    Container(ma, "Mobile App", "Xamarin", "Provides a limited subset ot the internet banking functionality to customers via their mobile mobile device.")
    ContainerDb(db, "Database", "Relational Database Schema", "Stores user registration information, hashed authentication credentials, access logs, etc.")
    System_Ext(mbs, "Mainframe Banking System", "Stores all of the core banking information about customers, accounts, transactions, etc.")
    
    Container_Boundary(api, "API Application") {
        Component(sign, "Sign In Controller", "MVC Rest Controlle", "Allows users to sign in to the internet banking system")
        Component(accounts, "Accounts Summary Controller", "MVC Rest Controlle", "Provides customers with a summory of their bank accounts")
        Component(security, "Security Component", "Spring Bean", "Provides functionality related to singing in, changing passwords, etc.")
        Component(mbsfacade, "Mainframe Banking System Facade", "Spring Bean", "A facade onto the mainframe banking system.")
    
        Rel(sign, security, "Uses")
        Rel(accounts, mbsfacade, "Uses")
        Rel(security, db, "Read & write to", "JDBC")
        Rel(mbsfacade, mbs, "Uses", "XML/HTTPS")
    }
    
    Rel(spa, sign, "Uses", "JSON/HTTPS")
    Rel(spa, accounts, "Uses", "JSON/HTTPS")
    
    Rel(ma, sign, "Uses", "JSON/HTTPS")
    Rel(ma, accounts, "Uses", "JSON/HTTPS")
    @enduml
    ```
    ```kroki-c4plantuml
    @startuml
    !include C4_Component.puml
    
    LAYOUT_WITH_LEGEND()
    
    title Component diagram for Internet Banking System - API Application
    
    Container(spa, "Single Page Application", "javascript and angular", "Provides all the internet banking functionality to customers via their web browser.")
    Container(ma, "Mobile App", "Xamarin", "Provides a limited subset ot the internet banking functionality to customers via their mobile mobile device.")
    ContainerDb(db, "Database", "Relational Database Schema", "Stores user registration information, hashed authentication credentials, access logs, etc.")
    System_Ext(mbs, "Mainframe Banking System", "Stores all of the core banking information about customers, accounts, transactions, etc.")
    
    Container_Boundary(api, "API Application") {
        Component(sign, "Sign In Controller", "MVC Rest Controlle", "Allows users to sign in to the internet banking system")
        Component(accounts, "Accounts Summary Controller", "MVC Rest Controlle", "Provides customers with a summory of their bank accounts")
        Component(security, "Security Component", "Spring Bean", "Provides functionality related to singing in, changing passwords, etc.")
        Component(mbsfacade, "Mainframe Banking System Facade", "Spring Bean", "A facade onto the mainframe banking system.")
    
        Rel(sign, security, "Uses")
        Rel(accounts, mbsfacade, "Uses")
        Rel(security, db, "Read & write to", "JDBC")
        Rel(mbsfacade, mbs, "Uses", "XML/HTTPS")
    }
    
    Rel(spa, sign, "Uses", "JSON/HTTPS")
    Rel(spa, accounts, "Uses", "JSON/HTTPS")
    
    Rel(ma, sign, "Uses", "JSON/HTTPS")
    Rel(ma, accounts, "Uses", "JSON/HTTPS")
    @enduml
    ```








### State machine

[State Machine](https://kroki.io/examples.html#state-machine){target="_none"}


