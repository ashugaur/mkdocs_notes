# Tufte image

<div class="md-has-sidebar">
    <main>
		<img src="img/relative_reference.png" alt="Holograms" width=15%><br>
    </main>

    <aside>
        This is a margin note – a sidenote without a footnote-style number.
        Footnotes aren't implemented yet, but would be nice to have, too.
    </aside>
</div>

