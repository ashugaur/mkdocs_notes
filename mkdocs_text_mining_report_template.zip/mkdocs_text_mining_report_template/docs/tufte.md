# Tufte

## code

<div class="md-has-sidebar">
    <main>
        ```python title="tufte-sidebars.css" linenums="1"
        x=1
        ```
    </main>

    <aside>
        This is a margin note – a sidenote without a footnote-style number.
        Footnotes aren't implemented yet, but would be nice to have, too.
    </aside>
</div>

## table

<div class="md-has-sidebar">
    <main>

		| Date        |   # of something |
		|:------------|-----------------:|
		| 21-Jun-2023 |               13 |
		| 21-Jul-2023 |               10 |
		| 20-Aug-2023 |               13 |
		| 19-Sep-2023 |               11 |
		| 19-Oct-2023 |               13 |
		| 18-Nov-2023 |               11 |
		| 18-Dec-2023 |               14 |
    </main>

    <aside>
        This is a margin note – a sidenote without a footnote-style number.
        Footnotes aren't implemented yet, but would be nice to have, too.
    </aside>
</div>

