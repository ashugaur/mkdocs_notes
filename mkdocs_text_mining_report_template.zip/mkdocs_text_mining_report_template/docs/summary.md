# Summary_table


## table

!!! text ""

	| Date        |   # of something |
	|:------------|-----------------:|
	| 21-Jun-2023 |               13 |
	| 21-Jul-2023 |               10 |
	| 20-Aug-2023 |               13 |
	| 19-Sep-2023 |               11 |
	| 19-Oct-2023 |               13 |
	| 18-Nov-2023 |               11 |
	| 18-Dec-2023 |               14 |



## table with image

!!! text ""

	<img src="img/relative_reference.png" alt="Holograms" width=15%><br>

	| Date        |   # of something |
	|:------------|-----------------:|
	| 21-Jun-2023 |               13 |
	| 21-Jul-2023 |               10 |
	| 20-Aug-2023 |               13 |
	| 19-Sep-2023 |               11 |
	| 19-Oct-2023 |               13 |
	| 18-Nov-2023 |               11 |
	| 18-Dec-2023 |               14 |


