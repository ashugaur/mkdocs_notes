#%% dependencies

import os
os.chdir(r"C:\Users\Ashutosh Gaur\My Drive\edupunk\docs".replace('\\', '/'))


# convert table to markdown: from dataframe
import pyperclip
import pandas as pd
pyperclip.copy(df.reset_index().to_markdown(index=False))
