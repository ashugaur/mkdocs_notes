---
hide:
    # - navigation
    # - toc
    - footer
---


# Insert.mermaid

## Mermaid

[Mermaid](https://mermaid-js.github.io/mermaid/#/){target="_blank"} | 
[Mermaid Live Editor](https://mermaid.live/edit#pako:eNplj0EPgjAMhf9K0zMXY7zsqsYTJ65cGlZlAqsZXQgh_neHSIK6U_e91_fSCSuxjAYB7hKD57H0kJ46bRnyEQYJjfM3sPRReq7UiYeLgMpbXjhATg2DMhk4GMh5xckYH72SC72B_VY5LfsGdjPN4Ej611FLt02yMvg166ulcPoWfyoww45DR86mG6eZlqg1p0w0abR8pdhqiaV_Jmt8WFI-W6cS0GiInCFFlWL01fpfPCdHt0DdAp8vWiNlbw){target="_blank"}


### Class diagram

#### E.g. 1

!!! info "Class diagram"
    ```
    classDiagram
    Class01 <|-- AveryLongClass : Cool
    Class03 *-- Class04
    Class05 o-- Class06
    Class07 .. Class08
    Class09 --> C2 : Where am i?
    Class09 --* C3
    Class09 --|> Class07
    Class07 : equals()
    Class07 : Object[] elementData
    Class01 : size()
    Class01 : int chimp
    Class01 : int gorilla
    Class08 <--> C2: Cool label
    ```
    ```mermaid
    classDiagram
    Class01 <|-- AveryLongClass : Cool
    Class03 *-- Class04
    Class05 o-- Class06
    Class07 .. Class08
    Class09 --> C2 : Where am i?
    Class09 --* C3
    Class09 --|> Class07
    Class07 : equals()
    Class07 : Object[] elementData
    Class01 : size()
    Class01 : int chimp
    Class01 : int gorilla
    Class08 <--> C2: Cool label
    ```

#### E.g. 2

!!! info "Class diagram"
    ```
    classDiagram
      Person <|-- Student
      Person <|-- Professor
      Person : +String name
      Person : +String phoneNumber
      Person : +String emailAddress
      Person: +purchaseParkingPass()
      Address "1" <-- "0..1" Person:lives at
      class Student{
        +int studentNumber
        +int averageMark
        +isEligibleToEnrol()
        +getSeminarsTaken()
      }
      class Professor{
        +int salary
      }
      class Address{
        +String street
        +String city
        +String state
        +int postalCode
        +String country
        -validate()
        +outputAsLabel()  
      }
    ```
    ```mermaid
    classDiagram
      Person <|-- Student
      Person <|-- Professor
      Person : +String name
      Person : +String phoneNumber
      Person : +String emailAddress
      Person: +purchaseParkingPass()
      Address "1" <-- "0..1" Person:lives at
      class Student{
        +int studentNumber
        +int averageMark
        +isEligibleToEnrol()
        +getSeminarsTaken()
      }
      class Professor{
        +int salary
      }
      class Address{
        +String street
        +String city
        +String state
        +int postalCode
        +String country
        -validate()
        +outputAsLabel()  
      }
    ```








### Entity Relationship Diagrams

#### E.g. 1

!!! info "Entity Relationship Diagram"
    ```
    erDiagram
        CUSTOMER ||--o{ ORDER : places
        ORDER ||--|{ LINE-ITEM : contains
        CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
    ```
    ```mermaid
    erDiagram
        CUSTOMER ||--o{ ORDER : places
        ORDER ||--|{ LINE-ITEM : contains
        CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
    ```


#### E.g. 2

!!! info "Entity Relationship Diagram"
    ```
    erDiagram
            CUSTOMER }|..|{ DELIVERY-ADDRESS : has
            CUSTOMER ||--o{ ORDER : places
            CUSTOMER ||--o{ INVOICE : "liable for"
            DELIVERY-ADDRESS ||--o{ ORDER : receives
            INVOICE ||--|{ ORDER : covers
            ORDER ||--|{ ORDER-ITEM : includes
            PRODUCT-CATEGORY ||--|{ PRODUCT : contains
            PRODUCT ||--o{ ORDER-ITEM : "ordered in"
    ```
    ```mermaid
    erDiagram
            CUSTOMER }|..|{ DELIVERY-ADDRESS : has
            CUSTOMER ||--o{ ORDER : places
            CUSTOMER ||--o{ INVOICE : "liable for"
            DELIVERY-ADDRESS ||--o{ ORDER : receives
            INVOICE ||--|{ ORDER : covers
            ORDER ||--|{ ORDER-ITEM : includes
            PRODUCT-CATEGORY ||--|{ PRODUCT : contains
            PRODUCT ||--o{ ORDER-ITEM : "ordered in"
    ```















### Flowchart

#### Orientations

Possible Flowchart orientations are:

- TB - top to bottom
- TD - top-down/ same as top to bottom
- BT - bottom to top
- RL - right to left
- LR - left to right


#### Comments

!!! info "Direction in subgraphs"
    ```
    flowchart LR
    %% this is a comment A -- text --> B{node}
       A -- text --> B -- text2 --> C
    ```
    ```mermaid
    flowchart LR
    %% this is a comment A -- text --> B{node}
       A -- text --> B -- text2 --> C
    ```


#### Arrow types

!!! info "New arrow types"
    ```
    flowchart LR
        A --o B
        B --x C
    ```
    ```mermaid
    flowchart LR
        A --o B
        B --x C
    ```

!!! info "Multi directional arrows"
    ```
    flowchart LR
        A o--o B
        B <--> C
        C x--x D
    ```
    ```mermaid
    flowchart LR
        A o--o B
        B <--> C
        C x--x D
    ```


#### Link length

!!! info "Minimum length of a link"
    ```
    flowchart TD
        A[Start] --> B{Is it?}
        B -- Yes --> C[OK]
        C --> D[Rethink]
        D --> B
        B -- No ----> E[End]
    ```
    ```mermaid
    flowchart TD
        A[Start] --> B{Is it?}
        B -- Yes --> C[OK]
        C --> D[Rethink]
        D --> B
        B -- No ----> E[End]
    ```


#### Node

!!! info "A node (default)"
    ```
    flowchart LR
    id
    ```
    ```mermaid
    flowchart LR
    id
    ```

#### Node with text

!!! info "Node with text"
    ```
    flowchart LR
        id1[This is the text in the box]
    ```
    ```mermaid
    flowchart LR
        id1[This is the text in the box]
    ```


#### Node shapes

!!! info "A node with round edges"
    ```
    flowchart LR
        id1(This is the text in the box)
    ```
    ```mermaid
    flowchart LR
        id1(This is the text in the box)
    ```

!!! info "A stadium-shaped node"
    ```
    flowchart LR
        id1([This is the text in the box])
    ```
    ```mermaid
    flowchart LR
        id1([This is the text in the box])
    ```


!!! info "A node in a subroutine shape"
    ```
    flowchart LR
        id1[[This is the text in the box]]
    ```
    ```mermaid
    flowchart LR
        id1[[This is the text in the box]]
    ```

!!! info "A node in a cylindrical shape"
    ```
    flowchart LR
        id1[(Database)]
    ```
    ```mermaid
    flowchart LR
        id1[(Database)]
    ```

!!! info "A node in the form of a circle"
    ```
    flowchart LR
        id1((This is the text in the circle))
    ```
    ```mermaid
    flowchart LR
        id1((This is the text in the circle))
    ```

!!! info "A node in an asymmetric shape"
    ```
    flowchart LR
        id1>This is the text in the box]
    ```
    ```mermaid
    flowchart LR
        id1>This is the text in the box]
    ```

!!! info "A node (rhombus)"
    ```
    flowchart LR
        id1{This is the text in the box}
    ```
    ```mermaid
    flowchart LR
        id1{This is the text in the box}
    ```


!!! info "A hexagon node"
    ```
    flowchart LR
        id1{{This is the text in the box}}
    ```
    ```mermaid
    flowchart LR
        id1{{This is the text in the box}}
    ```

!!! info "Parallelogram"
    ```
    flowchart LR
        id1[/This is the text in the box/]
    ```
    ```mermaid
    flowchart LR
        id1[/This is the text in the box/]
    ```

!!! info "Parallelogram alt"
    ```
    flowchart LR
        id1[\This is the text in the box\]
    ```
    ```mermaid
    flowchart LR
        id1[\This is the text in the box\]
    ```

!!! info "Trapezoid"
    ```
    flowchart LR
        A[/Diwali\]
    ```
    ```mermaid
    flowchart LR
        A[/Diwali\]
    ```

!!! info "Trapezoid alt"
    ```
    flowchart LR
        B[\Go shopping/]
    ```
    ```mermaid
    flowchart LR
        B[\Go shopping/]
    ```

!!! info "Double circle"
    ```
    flowchart LR
        id1(((This is the text in the circle)))
    ```
    ```mermaid
    flowchart LR
        id1(((This is the text in the circle)))
    ```

#### Text on links

!!! info "Text on links"
    ```
    flowchart LR
        A-- This is the text! ---B
    ```
    ```mermaid
    flowchart LR
        A-- This is the text! ---B
    ```

#### Dotted link with text

!!! info "Dotted link with text"
    ```
    flowchart LR
        A-. text .-> B
    ```
    ```mermaid
    flowchart LR
        A-. text .-> B
    ```




#### Chaining of links

!!! info "TD"
    ```
    graph TD
        A[Today] -- i went --> B((to office))
        A --> C(should i)
        B --> D{not}
        C --> D
    ```
    ```mermaid
    graph TD
        A[Today] -- i went --> B((to office))
        A --> C(should i)
        B --> D{not}
        C --> D
    ```

!!! info "LR"
    ```
    flowchart LR
       a --> b & c--> d
    ```
    ```mermaid
    flowchart LR
       a --> b & c--> d
    ```

!!! info "TB"
    ```
    flowchart TB
       A & B--> C & D
    ```
    ```mermaid
    flowchart TB
       A & B--> C & D
    ```


#### Code flow

!!! info "Code Flow"
    ```
    flowchart TB
        final -- inner join--> table_1 & table_2
        table_2 -- left join --> customer & sales & activity
    ```
    ```mermaid
    flowchart TB
        final -- inner join--> table_1 & table_2
        table_2 -- left join --> customer & sales & activity
    ```



#### Subgraphs

[Subgraphs](https://mermaid-js.github.io/mermaid/#/flowchart?id=subgraphs){target="_blank"}

###### E.g. 1

!!! info "Subgraphs"
    ```
    flowchart TB
        c1-->a2
        subgraph ide1 [one]
        a1-->a2
        end
    ```
    ```mermaid
    flowchart TB
        c1-->a2
        subgraph ide1 [one]
        a1-->a2
        end
    ```


###### E.g. 2

!!! info "Subgraphs"
    ```
    flowchart TB
        c1-->a2
        subgraph one
        a1-->a2
        end
        subgraph two
        b1-->b2
        end
        subgraph three
        c1-->c2
        end
    ```
    ```mermaid
    flowchart TB
        c1-->a2
        subgraph one
        a1-->a2
        end
        subgraph two
        b1-->b2
        end
        subgraph three
        c1-->c2
        end
    ```


###### E.g. 3

!!! info "Subgraphs"
    ```
    flowchart TB
        c1-->a2
        subgraph one
        a1-->a2
        end
        subgraph two
        b1-->b2
        end
        subgraph three
        c1-->c2
        end
        one --> two
        three --> two
        two --> c2
    ```
    ```mermaid
    flowchart TB
        c1-->a2
        subgraph one
        a1-->a2
        end
        subgraph two
        b1-->b2
        end
        subgraph three
        c1-->c2
        end
        one --> two
        three --> two
        two --> c2
    ```

###### E.g. 4

!!! info "Direction in subgraphs"
    ```
    flowchart LR
      subgraph TOP
        direction TB
        subgraph B1
            direction RL
            i1 -->f1
        end
        subgraph B2
            direction BT
            i2 -->f2
        end
      end
      A --> TOP --> B
      B1 --> B2
    ```
    ```mermaid
    flowchart LR
      subgraph TOP
        direction TB
        subgraph B1
            direction RL
            i1 -->f1
        end
        subgraph B2
            direction BT
            i2 -->f2
        end
      end
      A --> TOP --> B
      B1 --> B2
    ```



#### Styling

!!! info "Styling a node"
    ```
    flowchart LR
        id1(Start)-->id2(Stop)
        style id1 fill:#f9f,stroke:#333,stroke-width:4px
        style id2 fill:#bbf,stroke:#f66,stroke-width:2px,color:#fff,stroke-dasharray: 5 5
    ```
    ```mermaid
    flowchart LR
        id1(Start)-->id2(Stop)
        style id1 fill:#f9f,stroke:#333,stroke-width:4px
        style id2 fill:#bbf,stroke:#f66,stroke-width:2px,color:#fff,stroke-dasharray: 5 5
    ```





































### Gantt diagram

[Settings](https://github.com/mermaid-js/mermaid/blob/develop/docs/gantt.md){target="_blank"}

#### E.g. 1

!!! info "Gantt diagram"
    ```
    gantt
    dateFormat  YYYY-MM-DD
    title Adding GANTT diagram to mermaid
    excludes weekdays 2014-01-10
    
    section A section
    Completed task            :done,    des1, 2014-01-06,2014-01-08
    Active task               :active,  des2, 2014-01-09, 3d
    Future task               :         des3, after des2, 5d
    Future task2               :         des4, after des3, 5d
    ```
    ```mermaid
    gantt
    dateFormat  YYYY-MM-DD
    title Adding GANTT diagram to mermaid
    excludes weekdays 2014-01-10
    
    section A section
    Completed task            :done,    des1, 2014-01-06,2014-01-08
    Active task               :active,  des2, 2014-01-09, 3d
    Future task               :         des3, after des2, 5d
    Future task2               :         des4, after des3, 5d
    ```


#### E.g. 2

!!! info "Gantt diagram"
    ```
    gantt
        title A Gantt Diagram
        dateFormat  YYYY-MM-DD
    
        section New Product
        R&D                         :crit,    done,    rnd1, 2021-01-06, 24h
        Product line                :crit,    active,  rnd2, after rnd1, 12d
        Launch                      :crit,    active,  rnd3, 2021-01-08, 2d
        Support                     :crit,             rnd4, after rnd3, 24d
    
        section Country Expansion 
        Office                      :         done,    exp1, 2021-01-06, 2021-01-09
        Country launch              :         done,    exp2, after exp1, 4d
        Marketing                   :         active,  exp3, 2021-01-09, 18d
        PR                          :                  exp4, after exp2, 5d
    ```
    ```mermaid
    gantt
        title A Gantt Diagram
        dateFormat  YYYY-MM-DD
    
        section New Product
        R&D                         :crit,    done,    rnd1, 2021-01-06, 24h
        Product line                :crit,    active,  rnd2, after rnd1, 12d
        Launch                      :crit,    active,  rnd3, 2021-01-08, 2d
        Support                     :crit,             rnd4, after rnd3, 24d
    
        section Country Expansion 
        Office                      :         done,    exp1, 2021-01-06, 2021-01-09
        Country launch              :         done,    exp2, after exp1, 4d
        Marketing                   :         active,  exp3, 2021-01-09, 18d
        PR                          :                  exp4, after exp2, 5d
    ```






#### E.g. 3

!!! info "Gantt diagram"
    ```
    gantt
           dateFormat                YYYY-MM-DD
           title                     Adding GANTT diagram functionality to mermaid
           excludes                  :excludes the named dates/days from being included in a charted task..
           section A section
           Completed task            :done,    des1, 2014-01-06,2014-01-08
           Active task               :active,  des2, 2014-01-09, 3d
           Future task               :         des3, after des2, 5d
           Future task2              :         des4, after des3, 5d
    
           section Critical tasks
           Completed task in the critical line :crit, done, 2014-01-06,24h
           Implement parser and jison          :crit, done, after des1, 2d
           Create tests for parser             :crit, active, 3d
           Future task in critical line        :crit, 5d
           Create tests for renderer           :2d
           Add to mermaid                      :1d
    
           section Documentation
           Describe gantt syntax               :active, a1, after des1, 3d
           Add gantt diagram to demo page      :after a1  , 20h
           Add another diagram to demo page    :doc1, after a1  , 48h
    
           section Last section
           Describe gantt syntax               :after doc1, 3d
           Add gantt diagram to demo page      :20h
           Add another diagram to demo page    :48h
    ```
    ```mermaid
    gantt
           dateFormat                YYYY-MM-DD
           title                     Adding GANTT diagram functionality to mermaid
           excludes                  :excludes the named dates/days from being included in a charted task..
           section A section
           Completed task            :done,    des1, 2014-01-06,2014-01-08
           Active task               :active,  des2, 2014-01-09, 3d
           Future task               :         des3, after des2, 5d
           Future task2              :         des4, after des3, 5d
    
           section Critical tasks
           Completed task in the critical line :crit, done, 2014-01-06,24h
           Implement parser and jison          :crit, done, after des1, 2d
           Create tests for parser             :crit, active, 3d
           Future task in critical line        :crit, 5d
           Create tests for renderer           :2d
           Add to mermaid                      :1d
    
           section Documentation
           Describe gantt syntax               :active, a1, after des1, 3d
           Add gantt diagram to demo page      :after a1  , 20h
           Add another diagram to demo page    :doc1, after a1  , 48h
    
           section Last section
           Describe gantt syntax               :after doc1, 3d
           Add gantt diagram to demo page      :20h
           Add another diagram to demo page    :48h
    ```









### Pie Chart

#### E.g. 1

!!! info "Gantt diagram"
    ```
    pie
        title Key elements in Product X
        "Calcium" : 42.96
        "Potassium" : 50.05
        "Magnesium" : 10.01
        "Iron" :  5
    ```
    ```mermaid
    pie
        title Key elements in Product X
        "Calcium" : 42.96
        "Potassium" : 50.05
        "Magnesium" : 10.01
        "Iron" :  5
    ```



### Sequence diagram

#### E.g. 1

!!! info "Sequence diagram"
    ```
    sequenceDiagram
        Alice ->> Bob: Hello Bob, how are you?
        Bob-->>John: How about you John?
        Bob--x Alice: I am good thanks!
        Bob-x John: I am good thanks!
        Note right of John: Bob thinks a long<br/>long time, so long<br/>that the text does<br/>not fit on a row.
    
        Bob-->Alice: Checking with John...
    
        Alice->John: Yes... John, how are you?
    
        Note left of Alice: Hey!
    ```
    ```mermaid
    sequenceDiagram
        Alice ->> Bob: Hello Bob, how are you?
        Bob-->>John: How about you John?
        Bob--x Alice: I am good thanks!
        Bob-x John: I am good thanks!
        Note right of John: Bob thinks a long<br/>long time, so long<br/>that the text does<br/>not fit on a row.
    
        Bob-->Alice: Checking with John...
    
        Alice->John: Yes... John, how are you?
    
        Note left of Alice: Hey!
    ```




#### E.g. 2

!!! info "Sequence diagram"
    ```
    sequenceDiagram
        loop Daily query
            Alice->>Bob: Hello Bob, how are you?
            alt is sick
                Bob->>Alice: Not so good :(
            else is well
                Bob->>Alice: Feeling fresh like a daisy
            end
    
            opt Extra response
                Bob->>Alice: Thanks for asking
            end
        end
    ```
    ```mermaid
    sequenceDiagram
        loop Daily query
            Alice->>Bob: Hello Bob, how are you?
            alt is sick
                Bob->>Alice: Not so good :(
            else is well
                Bob->>Alice: Feeling fresh like a daisy
            end
    
            opt Extra response
                Bob->>Alice: Thanks for asking
            end
        end
    ```



#### E.g. 3

!!! info "Sequence diagram"
    ```
    sequenceDiagram
        participant Alice
        participant Bob
        Alice->>John: Hello John, how are you?
        loop Healthcheck
            John->>John: Fight against hypochondria
        end
        Note right of John: Rational thoughts<br/>prevail...
        John-->>Alice: Great!
        John->>Bob: How about you?
        Bob-->>John: Jolly good!
    ```
    ```mermaid
    sequenceDiagram
        participant Alice
        participant Bob
        Alice->>John: Hello John, how are you?
        loop Healthcheck
            John->>John: Fight against hypochondria
        end
        Note right of John: Rational thoughts<br/>prevail...
        John-->>Alice: Great!
        John->>Bob: How about you?
        Bob-->>John: Jolly good!
    ```

















### State Diagram

#### E.g. 1

!!! info "State diagram"
    ```
    stateDiagram
        direction LR
        [*] --> A
        A --> B
        B --> C
        state B {
          direction LR
          a --> b
        }
        B --> D
    ```
    ```mermaid
    stateDiagram
        direction LR
        [*] --> A
        A --> B
        B --> C
        state B {
          direction LR
          a --> b
        }
        B --> D
    ```


#### E.g. 2

!!! info "State diagram"
    ```
    stateDiagram-v2
      state fork_state <<fork>>
        [*] --> fork_state
        fork_state --> State2
        fork_state --> State3
    
        state join_state <<join>>
        State2 --> join_state
        State3 --> join_state
        join_state --> State4
        State4 --> [*]
    ```
    ```mermaid
    stateDiagram-v2
      state fork_state <<fork>>
        [*] --> fork_state
        fork_state --> State2
        fork_state --> State3
    
        state join_state <<join>>
        State2 --> join_state
        State3 --> join_state
        join_state --> State4
        State4 --> [*]
    ```







### User journey diagram

#### E.g. 1


!!! info "User journey diagram"
    ```
    journey
        title My working day
        section Go to work
          Make tea: 5: Me
          Go upstairs: 3: Me
          Do work: 1: Me, Cat
        section Go home
          Go downstairs: 5: Me
          Sit down: 5: Me
    ```
    ```mermaid
    journey
        title My working day
        section Go to work
          Make tea: 5: Me
          Go upstairs: 3: Me
          Do work: 1: Me, Cat
        section Go home
          Go downstairs: 5: Me
          Sit down: 5: Me
    ```

























