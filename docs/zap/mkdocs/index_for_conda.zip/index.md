---
hide:
    # - navigation
    # - toc
    - footer
---


# MkDocs Overview

Notes combine working code for Markdown, pandocs & mkdocs with bias towards mkdocs.



## Alternate

[`Markdoc`](https://github.com/markdoc/markdoc){target="_blank"}
[`Pandoc`](https://pandoc.org/){target="_blank"}
[`R Markdown`](https://rmarkdown.rstudio.com/){target="_blank"}



## Reference

### Documents

[`Material for MkDocs`](https://squidfunk.github.io/mkdocs-material/reference/){target="_blank"}
[`MkDocs MagicSpace`](https://mkdocs-magicspace.alnoda.org/tutorials/get-started/){target="_blank"}
[`Plugins`](https://github.com/mkdocs/mkdocs/wiki/MkDocs-Plugins){target="_blank"}
[`abinit`](https://docs.abinit.org/developers/markdown/#markdown-quick-reference){target="_blank"}
[`Hacks`](https://www.markdownguide.org/hacks/){target="_blank"}
[`Customize output`](https://medium.com/expedia-group-tech/customizing-mkdocs-html-output-1b4895417856){target="_blank"}
[`Customize code blocks`](https://rdmd.readme.io/docs/code-blocks){target="_blank"}


### Unicode Characters

[`Alchemy Symbols`](https://unicode-table.com/en/blocks/alchemical-symbols/){target="_blank"}
[`100+ Unicode Symbols`](https://tutorialzine.com/2014/12/you-dont-need-icons-here-are-100-unicode-symbols-that-you-can-use){target="_blank"}
[`Unicode Character Table`](https://unicode-table.com/en/blocks/){target="_blank"}
[`Unicode Character Table`](https://unicode-table.com/en/blocks/supplemental-symbols-and-pictographs/){target="_blank"}


### Publish on GitHub Pages

[`Publish`](https://mkdocs-magicspace.alnoda.org/tutorials/get-online/github-pages/){target="_blank"}




## Install

<code>
<a href="https://www.anaconda.com/" target="_blank">Anaconda</a>, 
 <a href="https://anaconda.org/conda-forge/mkdocs" target="_blank">MkDocs</a>, 
 <a href="https://anaconda.org/conda-forge/mkdocs-material" target="_blank">Material Theme</a>, 
 <a href="https://anaconda.org/conda-forge/mkdocs-material-extensions" target="_blank">Material extensions</a>, 
 <a href="https://anaconda.org/conda-forge/pygments" target="_blank">Pygments</a>, 
 <a href="https://pypi.org/project/mkdocs-localsearch/" target="_blank">Local search</a>, 
 <a href="https://github.com/wilhelmer/mkdocs-localsearch" target="_blank">Configure local search</a>, 
 <a href="https://anaconda.org/programfan/mkdocs-with-pdf" target="_blank">To pdf</a>, 
 <a href="https://squidfunk.github.io/mkdocs-material/reference/mathjax/" target="_blank">MathJax</a>,
 <a href="https://gitlab.com/rodrigo.schwencke/mkdocs-graphviz" target="_blank">mkdocs-graphviz</a>,
 <a href="https://timvink.github.io/mkdocs-charts-plugin/" target="_blank">mkdocs-charts-plugin</a>,
 <a href="https://pypi.org/project/mkdocs-jupyter/" target="_blank">mkdocs-jupyter</a>,
 <a href="https://pypi.org/project/mkdocs-video/" target="_blank">mkdocs-video</a>,
 <a href="https://pypi.org/project/mkdocs-kroki-plugin/" target="_blank">kroki</a>,
 <a href="https://pypi.org/project/mkdocs-material-extensions/" target="_blank">mkdocs-material-extensions</a>,
 <a href="https://pypi.org/project/mkdocs-material/" target="_blank">material theme</a>,
 <a href="https://pypi.org/project/mkdocs-table-reader-plugin/" target="_blank">table reader</a>,
 `pip install --upgrade setuptools`: if issues with pip
</code>



## Setup

`1.` Open Anaconda Prompt

```
Windows Start\Anaconda3\Anaconda Prompt
```

`2.` Go to folder where you want to create the project, e.g.

```
cd C:\test
```

`3.` Create new project

```
mkdocs new project-name
```

`4.` Go inside the project folder

```
cd project-name
```

`5.` Copy paste these lines into `project-name\mkdocs.yml`

=== "Simple"
    ```yaml
    site_name: test
    site_author: test
    site_url: https://test.com/
    ```
=== "Complex"
    ```
	# pakcages list
	# conda install -c conda-forge mkdocs
	# conda install -c conda-forge weasyprint
	# conda install -c conda-forge mkdocs-material
	# conda install -c conda-forge mkdocs-material-extensions
	# conda install -c programfan mkdocs-with-pdf
	# pip install mkdocs-with-pdf
	# pip install mkdocs-localsearch






	# ===========================================================
	# Attach library in python
	# ===========================================================
	# import os
	# os.chdir(r"C:\Users\Ashutosh Gaur\My Drive\edupunk".replace('\\', '/'))







	# ===========================================================
	# Configuration
	# ===========================================================
	site_name: Σdupunk
	# repo_url: https://gitlab.actilis.net/formation/docker/mkdocs-example.git
	# docs_dir: src
	site_author: AG
	site_url: https://edupunk.com/
	# left blank for material theme
	# site_url: ""
	# copyright: Copyright &copy; 2021 AG
	# edit_uri: ""








	# ===========================================================
	# Site structure
	# ===========================================================
	# nav:
	#     - Target: index.md
	#     - Automation:
	#         - About: automation\index.md
	#         - Anaconda: automation\conda.md
	#         - Foobar2000: automation\foobar2000.md
	#         - Notepad ++: automation\notepadpp.md
	#         - Powershell: automation\powershell.md
	#         - Windows: automation\windows.md

	#     - Data science:
	#         - About: ds\index.md

	#         - Analysis:
	#             - About: ds\analysis\index.md
	#             - ANOVA: ds\analysis\anova\index.md

	#             - Chi Square: ds\analysis\chi_square\index.md

	#             - Cluster Analysis: ds\analysis\cluster_analysis\index.md

	#             - Time Series Analysis: ds\analysis\ts\index.md


	#         - Books: ds\books.md
	#         - Concepts: ds\concepts.md
	#         - Distribution: ds\distributions.md
	#         - Hypothesis Testing: ds\hypothesis_testing.md
	#         - Hypothesis Test: ds\hypothesis_tests.md
	#         - Levels of Measurement: ds\lm.md
	#         - Measures of Central Tendency: ds\mct.md
	#         - Measures of Dispersion: ds\md.md
	#         - Measures of Shape: ds\ms.md
	#         - Probability: ds\probability.md
	#         - ROC & AUC: ds\roc_auc.md
	#         - Sampling: ds\sampling.md
	#         - Versus: ds\vs.md
		

	#     - Project Management:
	#         - Project Management: pm\index.md
	#         - Interview preparation: pm\ip.md
	#         - Apex: pm\apex.md
	#         - CRISP DM:
	#             - About: pm\cdm\index.md
	#             - Business Understanding: pm\cdm\1_bu.md
	#             - Data Understanding: pm\cdm\2_du.md
	#             - Data Preparation: pm\cdm\3_dp.md
	#             - Modeling: pm\cdm\4_m.md
	#             - Evaluation: pm\cdm\5_e.md
	#             - Deployment: pm\cdm\6_d.md
	#         - Six Sigma: pm\six_sigma.md

	#     - Reveries: reveries.md

	#     - Softwares:
	#         - Overview: software\index.md
	#         - d3.js:
	#             - Overview: software\d3.js\index.md
	#             - Learning Guide: software\d3.js\learning_guide.md
	#             - Angela Yu - Complete 2020 Web Development Bootcamp: software\d3.js\angela_yu_web_development_bootcamp.md
		
	#         - mkDocs:
	#             - Overview: software\mkdocs\index.md
	#             - Admonisions: software\mkdocs\admonisions.md
	#             - Code Blocks: software\mkdocs\code_blocks.md
	#             - Embed Documents: software\mkdocs\embed_docs.md
	#             - Graphics: software\mkdocs\graphics.md
	#             - Hyperlinks: software\mkdocs\hyperlinks.md
	#             - Icons Emojis: software\mkdocs\icons_emojis.md
	#             - Kroki: software\mkdocs\kroki.md
	#             - Lists: software\mkdocs\lists.md
	#             - Maths: software\mkdocs\maths.md
	#             - Mermaid: software\mkdocs\mermaid.md
	#             - Meta: software\mkdocs\meta.md
	#             - MkDocs Jupyter: software\mkdocs\mkdocs_jupyter.md
	#             # - MkDocs Jupyter example: mkdocs_jupyter_example.ipynb
	#             # - MkDocs HTML: software\mkdocs\mkdocs_html.html
	#             - Search: software\mkdocs\search.md
	#             - Spellcheck: software\mkdocs\spellcheck.md
	#             - Symbols: software\mkdocs\symbols.md
	#             - Tables: software\mkdocs\tables.md
	#             - Text: software\mkdocs\text_formatting.md

	#         - R:
	#             - About: software\r\index.md

	#         - SQL: software\sql\index.md
	#         - Tableau: software\tableau\index.md
	#         - QlikSense: software\qliksense\index.md

	#     - Stock Market: stock market\stock_market.md

	#     - Visual Library:
	#         - Visual Library: vl\index.md
	#         # - All: vl\all.md
	#         - Change: vl\change\index.md
	#         - Custom: vl\custom\index.md
	#         - Compare: vl\compare\index.md
	#         - Composition: vl\composition\index.md
	#         - Correlation: vl\correlation\index.md
	#         - Deviation: vl\deviation\index.md
	#         - Distribution: vl\distribution\index.md
	#         - Flow: vl\flow\index.md
	#         - Group: vl\group\index.md
	#         - Rank: vl\rank\index.md

	#     - About: about.md










	# ===========================================================
	# Appearance
	# ===========================================================
	# https://github.com/mkdocs/mkdocs/wiki/MkDocs-Themes
	# # mkdocs default theme
	# theme:
	#     name: mkdocs
	# # navigation page turns dark blue
	#     nav_style: dark
	#     highlightjs: true
	#     hljs_languages:
	#         - yaml
	#         - rust
	#     shortcuts:
	#         help: 191    # ?
	#         next: 78     # n
	#         previous: 80 # p
	#         search: 83   # s
	#     navigation_depth: 3
	#     sticky_navigation: False


	# https://github.com/gristlabs/mkdocs-windmill
	# theme:
	#     name: windmill


	# https://github.com/noraj/mkdocs-windmill-dark
	# theme:
	#     name: windmill-dark


	# https://anaconda.org/conda-forge/mkdocs-material
	# https://squidfunk.github.io/mkdocs-material/setup/changing-the-colors/
	# theme:
	#     name: material
	# # step 4 to enable local search
	#     custom_dir: theme

	# # page color theme
	#     palette:
	#         # primary: white
	#         # primary: blue grey
	#         primary: black
	#         accent: orange


	# theme:
	#     name: material
	#     palette: 

	#     # Palette toggle for light mode
	#         - scheme: default
	#           toggle:
	#             icon: material/brightness-7 
	#             name: Switch to dark mode

	#     # Palette toggle for dark mode
	#         - scheme: slate
	#           toggle:
	#             icon: material/brightness-4
	#             name: Switch to light mode


	theme:
		name: material
	# step 4 to enable local search
		custom_dir: theme
		palette:
			# Palette toggle for light mode
			- media: "(prefers-color-scheme: light)"
			  scheme: default
			  toggle:
				icon: material/lightbulb
				name: Switch to dark mode
			  accent: orange
			  # primary: white
			  primary: blue grey
			  # primary: grey
			
			# Palette toggle for dark mode
			- media: "(prefers-color-scheme: dark)"
			  scheme: slate
			  toggle:
				icon: material/lightbulb-outline
				name: Switch to light mode
			  accent: orange
			  primary: black

	# theme:
	#   palette:
	#     primary: deep orange

	# allows overrides; did not work
	# theme:
	#     name: material
		# custom_dir: overrides


	# theme:
	#     name: readthedocs
	#     highlightjs: true
	#     hljs_languages:
	#         - yaml
	#         - rust

	# change font
		font:
			text: Roboto
			# code: Roboto Mono

	# # change website logo    
		# logo: img/website_logo.png

	# # change favicon
		# favicon: img/website_logo.png

		features:

	# search options
	# https://www.codeinsideout.com/blog/site-setup/create-site-project/#navigation
	# theme:
	#     name: material
	#     features:
			- search.suggest # display the likeliest completion for the last word
			- search.highlight # highlight all occurrences
			- search.share # show a share button


	# changes the topic name in address bar
			- navigation.tracking

	# loads page fast       
	# https://squidfunk.github.io/mkdocs-material/setup/setting-up-navigation/
			- navigation.instant

	# enables top-level sections are rendered in a menu layer below the header for viewports above 1220px, but remain as-is on mobile
			- navigation.tabs

	# navigation tabs always visible
			# - navigation.tabs.sticky

	# shows toc sections as open all the time
			# - navigation.sections

	# integrates table of contents to one side
			# - toc.integrate

	# shows back to top button
			- navigation.top

	# all content tabs across the whole documentation site will be linked and switch to the same label when the user clicks on a tab
			# - content.tabs.link

	# theme:
		# icon:
		#     admonition:
		#         <type>: <icon> 

	# allows anotation within code blocks
	# theme:
		# features:
			- content.code.annotate 

	# When section index pages are enabled, documents can be directly attached to sections, which is particularly useful for providing overview pages
			- navigation.indexes


	# enabled = navigation opens as expanded
	# https://hpcai.tech/setup/setting-up-navigation/#navigation-expansion
			# - navigation.expand



	# customize admonision icons
	# https://squidfunk.github.io/mkdocs-material/reference/admonitions/#admonition-icons
	# theme:
		icon:
			admonition:
			  info: material/code-tags
			  question: material/lock-question
			  todo: fontawesome/solid/question










	# ===========================================================
	# Graphics
	# ===========================================================

	# mermaid support to create diagrams
	markdown_extensions:


	# https://squidfunk.github.io/mkdocs-material/reference/images/
	# enables image alignment
	# markdown_extensions:
		- attr_list
		- md_in_html


	# arbitrary nesting of code and content blocks inside each other, including admonitions, tabs, lists and all other elements
	# https://squidfunk.github.io/mkdocs-material/setup/extensions/python-markdown-extensions/#superfences
		- pymdownx.superfences:
			custom_fences:
				- name: mermaid
				  class: mermaid
				  format: !!python/name:pymdownx.superfences.fence_code_format


	# enable mkdocs-charts-plugin
				- name: vegalite
				  class: vegalite
				  format: !!python/name:mkdocs_charts_plugin.fences.fence_vegalite


	# enable graphviz extension
	# https://eskool.gitlab.io/mkhack3rs/graphviz/
	# markdown_extensions:
		# - mkdocs_graphviz

	# markdown_extensions:
	#     - mkdocs_graphviz:
	#         light_theme: 000000      # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         dark_theme: FFFFFF       # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         color: 789ABC            # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         bgcolor: none            # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         graph_color: 789ABC      # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         graph_fontcolor: 789ABC  # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         node_color: 789ABC       # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         node_fontcolor: 789ABC   # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         edge_color: 789ABC       # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign
	#         edge_fontcolor: 789ABC   # Any HTML Color Name or any HTML Hexadecimal color code WITHOUT the `#` sign





	# math formula
	# https://squidfunk.github.io/mkdocs-material/reference/mathjax/
	# conda install -c conda-forge pymdown-extensions
	# markdown_extensions:
		- pymdownx.arithmatex:
			generic: true




	# https://squidfunk.github.io/mkdocs-material/reference/code-blocks/
	# conda install -c conda-forge pygments
	# code block highlighting        
		- pymdownx.highlight:
			anchor_linenums: true
		- pymdownx.inlinehilite
		- pymdownx.snippets


	# admonitions
		- admonition
		- pymdownx.details
		# - pymdownx.superfences
	# tabs for comparison, code blocks
		- pymdownx.tabbed:
			alternate_style: true

	# list & checkbox style change
		- def_list
		- pymdownx.tasklist:
			custom_checkbox: true

		- footnotes


	# text formatting

	# markdown_extensions:
		- pymdownx.critic
		- pymdownx.caret
		- pymdownx.keys
		- pymdownx.mark
		- pymdownx.tilde


	# tooltips
		- abbr
		# - attr_list
		- pymdownx.snippets


	# Icons, Emojis
	# https://squidfunk.github.io/mkdocs-material/reference/icons-emojis/
	# markdown_extensions:
		- attr_list
		- pymdownx.emoji:
			emoji_index: !!python/name:materialx.emoji.twemoji
			emoji_generator: !!python/name:materialx.emoji.to_svg


	# markdown_extensions: 
	  # - attr_list
		- md_in_html



	# table support
	# https://squidfunk.github.io/mkdocs-material/reference/data-tables/#configuration
	# markdown_extensions:
		- tables


	# hides toc navigation for a particular file
	# https://squidfunk.github.io/mkdocs-material/setup/setting-up-navigation/#hiding-the-sidebars
		- meta


	# enable or disable display of toc levels by choosing 0
		- toc:
			# sets the title of the table of contents in the right navigation sidebar
			title: Table of Contents
			# adds an anchor link containing the paragraph symbol ¶ or another custom symbol at the end of each headline
			permalink: true
			permalink: '⚓︎'
			toc_depth: 4
			baselevel: 1
		# - pymdownx.betterem:
		#     smart_enable: all
		# - pymdownx.caret
		# - pymdownx.critic
		# - pymdownx.details
		# - pymdownx.emoji:
		#     emoji_generator: !!python/name:pymdownx.emoji.to_svg
		# - pymdownx.inlinehilite

		# enables linking within code block or yaml
		# https://facelessuser.github.io/pymdown-extensions/extensions/magiclink/
		# - pymdownx.magiclink

		# - pymdownx.mark
		# - pymdownx.smartsymbols
		# - pymdownx.superfences
		# - pymdownx.tasklist:
		#     custom_checkbox: true
		# - pymdownx.tilde





	# ===========================================================
	# Search
	# ===========================================================
	# # enables offline search
	# # paid plugin
	# plugins:
	#     - offline:
	#         enabled: !ENV [OFFLINE, false]


	# https://github.com/wilhelmer/mkdocs-localsearch
	plugins:


	# Embed excel file
	# https://pypi.org/project/mkdocs-table-reader-plugin/
	# https://timvink.github.io/mkdocs-table-reader-plugin/readers/#read_excel
		- table-reader
	#        data_path: "docs/tables"


	# add .py and .ipynb (jupyter notebooks) directly to nav
	# https://github.com/danielfrg/mkdocs-jupyter
	# plugins:
		- mkdocs-jupyter
			# execute: True
			# kernel_name: python3
			# include_source: True # show download button
			# - ignore_h1_titles: True

	# https://pypi.org/project/mkdocs-video/
		- mkdocs-video:
			# is_video: True
			# video_autoplay: True
			css_style:
			  width: "50%"
			  height: "22.172vw"

		- search
		- localsearch
		# - awesome-pages # order items in navbar using .pages


	# enable mkdocs-charts-plugin
		# - charts

	# enable kroki diagrams plugin
	# https://github.com/AVATEAM-IT-SYSTEMHAUS/mkdocs-kroki-plugin
	# plugins:
		- kroki




	# links pages for offline use
	use_directory_urls: false


	# switch off searchbox for offline usage
	# plugins: []
	# plugins:
	#     - search
	# https://github.com/midnightprioriem/mkdocs-autolinks-plugin
		# - autolinks
		# - minify
		#     minify_html: true








	# ===========================================================
	# Export
	# ===========================================================
	# convert mkdocs to pdf
	# conda install -c programfan mkdocs-with-pdf
	# https://github.com/orzih/mkdocs-with-pdf
	# https://morioh.com/p/31a9b684385a
	# https://pypi.org/project/mkdocs-with-pdf/
	# plugins:
	#     - with-pdf:
	#         author: Ashu
	#         copyright: Internal
			
	#         cover: true
	#         back_cover: true
	#         cover_title: Σdupunk
	#         cover_subtitle: Σdupunk notes
	#         cover_logo: docs\mkdocs\auhg.jpg


	# #         # custom_template_path: TEMPLATES PATH
			
	#         toc_title: Σdupunk site contents
	# #         # heading_shift: false
	#         toc_level: 3
	# #         # ordered_chapter_level: 2
	# #         # excludes_children:
	# #         #     - 'release-notes/:upgrading'
	# #         #     - 'release-notes/:changelog'
			
	# #         # exclude_pages:
	# #         #     - 'bugs/'
	# #         #     - 'appendix/contribute/'
	#         convert_iframe:
	#             - src: IFRAME SRC
	#               img: POSTER IMAGE URL
	#               text: ALTERNATE TEXT
	#             - src: ...
	# #         # two_columns_level: 3

	#         # render_js: true
	#         # headless_chrome_path: headless-chromium
			
	# #         # output_path: any-place/document.pdf
	#         # enabled_if_env: ENABLE_PDF_EXPORT
			
	# #         # debug_html: true
	# #         # show_anchors: true
	# #         verbose: false









	# math formula
	extra_javascript:
		- assets/javascripts/mathjax.js
		- https://polyfill.io/v3/polyfill.min.js?features=es6
		- https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js



	# enable mkdocs-charts-plugin
		- https://cdn.jsdelivr.net/npm/vega@5
		- https://cdn.jsdelivr.net/npm/vega-lite@5
		- https://cdn.jsdelivr.net/npm/vega-embed@6


	# enable graphviz extension
	# https://eskool.gitlab.io/mkhack3rs/graphviz/
	# extra_javascript:
		# - https://cdn.jsdelivr.net/gh/rod2ik/cdn@main/mkdocs/javascripts/mkdocs-graphviz.js


	# sortable tables
	# https://squidfunk.github.io/mkdocs-material/reference/data-tables/#sortable-tables
	# extra_javascript:
		- https://unpkg.com/tablesort@5.3.0/dist/tablesort.min.js
		- javascripts/tablesort.js



	# activate option to add additional text as table of content
	# https://github.com/midnightprioriem/mkdocs-toc-sidebar-plugin
	# plugins:
		# - search
		# - toc-sidebar




	# page width
	# https://squidfunk.github.io/mkdocs-material/setup/setting-up-navigation/#__tabbed_9_2
	extra_css:
		- stylesheets/extra.css



	# remove made with mkdocs
	# https://squidfunk.github.io/mkdocs-material/setup/setting-up-the-footer/#generator-notice
	# extra:
	#     generator: false
    ```

`6.` Start the project

```
mkdocs serve
```

`7.` Go to `127.0.0.1:8000` in Microsoft Edge or Chrome

`8.` Open `project-name\docs\index.md` in notepad or an editor of your preference

`9.` Write things down & see them reflect on the page

`10.` After finishing writing run the 2 commands

```
ctrl + c
mkdocs build
```

