---
# title: HTML tags
hide:
    # - navigation
    # - toc
    # - footer
---

# HTML tags

## Code block with side notes

<div class="md-has-sidebar">
    <main>
        ```py
        x=1
        ```
    </main>

    <aside>
        This is a margin note.
    </aside>
</div>



## Code block without lines and side notes

<div class="md-has-sidebar">
    <main>
        ```py linenums="0"
        x=1
        ```
    </main>

    <aside>
        This is a margin note.
    </aside>
</div>


## Plain text with side notes

<div class="md-has-sidebar">
    <main>
        x=1
    </main>

    <aside>
        This is a margin note.
    </aside>
</div>

