---
title: CRISP DM template
hide:
    # - navigation
    # - toc
    # - footer
---

## Overview

The Cross Industry Standard Process for Data Mining ([CRISP-DM](https://www.datascience-pm.com/crisp-dm-2/){target="_blank"}) is a process model with six phases that naturally describes the data science life cycle.



## Business Understanding

### Determine business objectives

!!! text ""

    Background, Business objectives, Business success criteria.


### Situation assessment

!!! text ""

    Inventory of resources, Requirements, assumptions and constraints, Risks and contingencies Terminonogy, Costs and benefits.


### Determine data mining goals

!!! text ""

    Data mining goals, Data mining success criteria.


### Produce project plan

!!! text ""

    Project plan, Initial assessment of tools and techniques.




## Data Understanding

### Collect initial data

!!! text ""

    Write...


### Describe data

!!! text ""

    Write...


### Explore data

!!! text ""

    Write...


### Verify data quality

!!! text ""

    Write...



## Data Preparation

### Data set

!!! text ""

    Write...


### Data set description

!!! text ""

    Write...


### Select data

!!! text ""

    Write...


### Clean data

!!! text ""

    Write...


### Construct data

!!! text ""

    Write...


### Integrate data

!!! text ""

    Write...


### Format data

!!! text ""

    Write...




## Modeling

### Select modeling techniques

!!! text ""

    Modeling technique, Modeling assumptions.


### Generate test design

!!! text ""

    Write...


### Build model

!!! text ""

    Parameter settings, Models, Model description.


### Assess model

!!! text ""

    Model assessment, Revised parameter settings.





## Evaluation

### Evaluate results

!!! text ""

    Write...


### Review process

!!! text ""

    Write...


### Determine next steps

!!! text ""

    Write...




## Deployment

### Plan deployment

!!! text ""

    Write...



### Plan monitoring and maintenance

!!! text ""

    Write...


### Produce final report

!!! text ""

    Write...


### Review project

!!! text ""

    Write...
