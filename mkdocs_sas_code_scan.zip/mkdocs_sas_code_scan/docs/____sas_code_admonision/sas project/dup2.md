# dup2

??? console-line "d2_code1"

	## d2_code1.sas

	```sas linenums="1"
	data work.rest;
	     First = 'Ipswich, England';
	     City = substr(First,1,7);
	     City_Country = City!!', '!!'England';
	run;
	proc print data = rest;
	run;

	```

??? console-line "d2_code2"

	## d2_code2.sas

	```sas linenums="1"
	data work.Employee;
	input name$ age;
	datalines;
	Bruce 30
	Dan 35
	;
	run;
	proc print data = work.employee;
	run;
	
	data work.Salary;
	input name$ salary;
	datalines;
	Bruce 40000
	Bruce 35000
	Dan 37000
	Dan -
	;
	run;
	proc print data = work.salary;
	run;
	*empsalary is missing semi colon;
	data work.empsalary;
	merge work.Employee (in = inemp)
	work.Salary (in = insal);
	by name;
	if inemp and insal;
	run;
	
	
	proc print data = work.empsalary;
	run;
	*when used with set statement does not produce any observations;
	data work.empsalaryk;
	set work.Employee (in = inemp)
	work.Salary (in = insal);
	by name;
	if inemp and insal;
	run;
	proc print data = work.empsalaryk;
	run;
	```

