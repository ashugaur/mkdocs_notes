---
title: 'MKdocs lite'
description: 'Lite templates'
author: 'AG'
date: 2023-04-13
# hide:
    # - navigation
    # - toc
    # - footer
---

<h1 style="padding:0 margin-top:0px"></h1>

## Overview

!!! text ""

    Below are steps to use this standard site document, <font color="red">instructions are in red</font>.

    Once you test out everything on this page it is recommended to refer to [mkdocs detailed command list](settings\mkdocs\1_text.md).


## Install python

!!! text ""

    <font color="red">[python.org](https://www.python.org/){target="_blank"}</font>


## Open powershell

!!! text ""

    <font color="red">When you open powershell python base environment is activated by default.<br>Here you are seeing a base environment with the name *mkdocs_lite*, on your machine you may see something like *(base)* or *PS*,</font>

    ![align_center](img/mkdocs_lite_step_0.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}

    <font color="red">to check if mkdocs is installed type this command in powershell, you shall see some python package names and version,</font>

    ```powershell linenums="0"
    pip list
    ```

    ![relative reference](img\mkdocs_lite_step_0_0.png){#id .class width=100% height=100%; loading=lazy}

    <font color="red">powershell may ask you to upgrade pip and provide command as after the text `[   ] to update, run:` in this screenshot,</font>

    ![align_center](img/mkdocs_lite_step_0_0.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}

    <font color="red">it is recommended to update pip.</font>

    ![align_center](img/mkdocs_lite_step_0_1.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}

    <font color="red">You may want to check powershell command execution policy,</font>

    ```powershell linenums="0"
    Get-ExecutionPolicy
    ```

    ![align_center](img/mkdocs_lite_step_0_2.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}

    <font color="red">if restricted you can change it using</font>

    ```powershell linenums="0"
    set-ExecutionPolicy -ExecutionPolicy Unrestricted
    ```

    ![align_center](img/mkdocs_lite_step_0_3.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}



## Install MkDocs & its dependencies

!!! text ""

    <font color="red">Use this command, the requirements file is within the project folder: *mkdocs_lite\mkdocs_lite_packages.txt*</font>

    ```powershell linenums="0"
    pip install -r "<path-for-mkdocs_lite_packages.txt>"
    ```

    ![align_center](img/mkdocs_lite_step_1.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}



## Use this project

!!! text ""

    <font color="red">Go to the folder path where this project is saved e.g. **c:\mkdocs_lite**</font>

    ```powershell linenums="0"
    cd <folder-path-where-you-have-mkdocs_lite>
    ```

    ![align_center](img/mkdocs_lite_step_4.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}


    <font color="red">once inside the folder, you may run the current project using</font>

    ```powershell linenums="0"
    mkdocs serve
    ```

    <font color="red">if above command did not work,</font>

    ```powershell linenums="0"
    python -m mkdocs serve
    ```

    ![align_center](img/mkdocs_lite_step_5.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}



    <font color="red">to build site</font>


    ```powershell linenums="0"
    mkdocs build
    ```

    <font color="red">if above command did not work,</font>

    ```powershell linenums="0"
    python -m mkdocs build
    ```

    ![align_center](img/mkdocs_lite_step_6.png){: .center style="height: 100%; width: 100%; border-radius: 5px;" loading=lazy}

    <font color="red">this will create a similar folder structure within the project folder, you may open **index.html** to see the output.</font>

    ![align_center](img/mkdocs_lite_step_7.png){style="height: 20%; width: 20%; border-radius: 5px;" loading=lazy}






## Write Markdown

!!! text ""

    <font color="red">Once the above steps are tested you may create markdown files (create new .txt file and rename the extenstion to .md) within the **mkdocs_lite\docs** folder.</font>


### General text

!!! text ""

    !!! text ""

		    `Plain text.`

    !!! text ""

		    Normal text.

	!!! text ""
	
			# Heading1

	!!! text ""
	
			## Heading2

	!!! text ""
		
			### Heading3



### Sentences within a box or admonision

!!! text ""

    === "Output"
        !!! text ""
            Write things like this sentence.

            Write more sentences.
    === "Markdown"
        ```
        !!! text ""

            Write things like this sentence.

            Write more sentences.
        ```



### Code blocks

!!! text ""

    === "Output"
        ```py
        import tensorflow as tf
        ```
    === "Markdown"
        ```
         ```py
         import tensorflow as tf
         ```
        ``` 






