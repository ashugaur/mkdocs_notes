*[HTML]: Hyper Text Markup Language
*[abra]: dabra
*[anything]: manytings