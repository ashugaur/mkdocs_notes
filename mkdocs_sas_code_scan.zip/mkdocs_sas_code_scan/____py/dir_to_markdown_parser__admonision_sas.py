#%% parse question and answers sheet to markdown

"""
objective: automate sas code page creation
source: sas code folder
description: na

data_dictionary: na


Testing
-------
_source = r'C:\my_disk\edupunk\analytics_application\____projects\mkdocs\mkdocs_sas_code_scan\____sas_code_tufte'
_destination = r'C:\my_disk\edupunk\analytics_application\____projects\mkdocs\mkdocs_sas_code_scan\docs'
"""


def dir_to_markdown_parser_sas_admonision(_source, _destination):

    global scan

    import pandas as pd
    import pathlib
    from pathlib import Path
    import os
    import glob
    import shutil

    os.chdir(_destination.replace('\\', '/'))

    _relevant_file_type = ['.sas']

    # remove folder
    shutil.rmtree(_source.split('\\')[-1])
    
    # create folder
    pathlib.Path(_source.split('\\')[-1]).mkdir(parents=True, exist_ok=True) 


    # scan folder
    def scan_dir(location_to_scan):
        global scan
        scan = []
        for i in glob.iglob(rf"{location_to_scan}\**\*", recursive=True):
            scan.append(i)
        if len(scan) > 0:
            scan = pd.DataFrame(scan).rename(columns={0: 'unc'})
            scan['filename'] = scan['unc'].apply(lambda row: Path(row).name)
            scan['ext'] = scan['unc'].apply(lambda row: os.path.splitext(os.path.basename(row))[1])
        else:
            scan = pd.DataFrame({'filename': ''}, index=([0]))

    scan_dir(_source)

    # flag files and folders
    for i in range(0, len(scan)):
        _unc = scan.loc[i, 'unc']
        if os.path.exists(_unc):
            scan.loc[i, 'dir_flag'] = os.path.isdir(_unc)
            scan.loc[i, 'file_flag'] = os.path.isfile(_unc)

    # filter relevant unc
    scan = scan[scan['file_flag']]
    scan = scan[scan['ext'].isin(_relevant_file_type)]
    #scan['relevant'] = np.where(scan['ext'].isin(_relevant_file_type), 1, 0)

    # dir depth
    scan['unc'] = scan['unc'].str.replace('\\', '/')
    scan['depth'] = scan['unc'].str.count('/') - _source.count('\\') - 1
    scan['unc_l1'] = (scan['unc'].str.rsplit('/', expand=True, n=2)[0]).str.replace('/'.join(_source.split('\\')[:-1]), _destination.replace('\\', '/'))
    scan['_unc_md'] = (scan['unc'].str.rsplit('/', expand=True, n=1)[0]).str.replace('/'.join(_source.split('\\')[:-1]), _destination.replace('\\', '/'))+'.md'

    # create folder structure
    for i in scan[scan['depth']>1]['unc_l1'].drop_duplicates():
        #print(i)
        pathlib.Path(i).mkdir(parents=True, exist_ok=True) 

    # write markdown
    select = scan[['unc', '_unc_md', 'filename', 'ext']].sort_values(['_unc_md', 'filename'])
    select['_filename'] = select['filename'].str.rsplit('.', expand=True, n=1)[0]
    #select = select[select['ext'].isin(['.sql'])]
    for _topic in select['_unc_md'].unique().tolist():
        _td = select[select['_unc_md'] == _topic].reset_index(drop=True)
        _file = _td['_unc_md'].unique()[0]
        _filemd = (_file.rsplit('/')[-1]).rsplit('.')[0]

        with open(_file, 'w', encoding="utf-8") as f:
            #f.write('---\n# title: '+_filemd+'\nhide:'+'\n\t# - navigation'+'\n\t# - toc'+'\n\t# - footer'+'\n---\n\n')
            f.write('# '+_filemd+'\n\n')
            for unc, _unc_md, filename, ext, _filename in _td.itertuples(index=False):

                _ext = ext.split('.')[1]
                _filename = filename.split('.')[0]

                f.write('??? '+'console-line'+' "'+_filename+'"\n\n')
                f.write('\t## '+filename+'\n\n')
                #f.write('<div class="md-has-sidebar">\n\t<main>\n')
                f.write('\t```'+_ext+' linenums="1"'+'\n')
                _sas_str = ''
                try:
                    for _sas_substrx in open(unc, encoding='unicode_escape').readlines():
                        _sas_str = _sas_str+'\t'+_sas_substrx
                except (UnicodeDecodeError):
                    for _sas_substrx in open(unc, encoding='utf-8').readlines():
                        _sas_str = _sas_str+'\t'+_sas_substrx
                f.write(_sas_str+'\n')
                f.write('\t```'+'\n\n')
                #f.write('\t</main>\n\n\t<aside>\n')
                #f.write('\t\t.'+'\n')
                #f.write('\t</aside>\n</div>\n\n\n')

dir_to_markdown_parser_sas_admonision(_source=r'C:\my_disk\edupunk\analytics_application\____projects\mkdocs\mkdocs_sas_code_scan\____sas_code_admonision',
                           _destination=r'C:\my_disk\edupunk\analytics_application\____projects\mkdocs\mkdocs_sas_code_scan\docs')
